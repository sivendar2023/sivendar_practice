package com.example.coreex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCore1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
