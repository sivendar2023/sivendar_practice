package com.example.coreex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCore1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringCore1Application.class, args);
	}

}
